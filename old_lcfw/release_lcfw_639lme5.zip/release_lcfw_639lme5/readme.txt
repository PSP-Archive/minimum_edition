LCFW 6.39LME installer for OFW6.39

-- What is this? -- 
This is LCFW installer for OFW6.39.
Only work on 01g ,02g , 03g, 04g, 07g and 09g model.
05g (GO)is not supported.

The degree of stability is still unknown. 
Please test it on your own and refer to different people's test reports.


-- How to use --
Copy "installer" folder and "launcher" folder at "ms0:/PSP/GAME/"

-- Preparation --
First. You need to install LCFW modules in your PSP.

1.Execute "639 installer" from XMB.
2.You can select these action:
Press x to install LCFW.
Press [] to uninstall LCFW.
Press R to exit.

After the action, PSP will rboot.

-- Start LCFW --
1.Execute "639 launcher" from XMB.
2. enjoy :)

-- How to enter RecoveryMenu? --
From XMB :Open VshMenu and select "Enter Recovery ->"
From LCFW:Execute "639 launcher" again.
From OFW :Execute "639 launcher" with hold "R".

-- credit --
some1: For his sceHttpStorageOpen kxploit.
liquidzigong: For his 639kxploit POC.
bbtgp: For his PrxEncrypter.
J416: For his rebootex sample.

Thanks for beta tester
@tablet6883
@Zooner_MT
@sayane_0032
@apolo1192
@PopStatue
@dsk_ro_ra
@potechihime
@Mr__Nerve
@wakatake0507
@tsumurin21
@altheme0r
@gluishia
@__taba__
@g_thail
@Satan_Rage
@teck4
@SnyFbSx

-- history --
v5
-- Added RecoveryMenu option in vshmenu.
-- Fixed a bug in OE driver.
v4
-- Fixed a bug when enter suspend with VshMenu opened.
-- Fixed MEdriver bug.
-- Added BatteryConfig submenu in RecoveryMenu.
-- Added Speed up MS option(beta).
v3
-- Update 639Launcher. Now you can switch between PRO-B6 and ME-3 :)


