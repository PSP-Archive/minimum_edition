LCFW 6.60LME installer for OFW6.60

-- What is this? -- 
This is LCFW for OFW6.60.

The degree of stability is still unknown. 
Please test it on your own and refer to different people's test reports.


-- How to use --
Copy "installer" folder and "launcher" folder at "ms0:/PSP/GAME/"

-- Preparation --
First. You need to install LCFW modules in your PSP.

1.Execute "LME Installer for 6.60" from XMB.
2.You can select these action:
Press x to install LCFW.
Press [] to uninstall LCFW.
Press R to exit.

After the action, PSP will rboot.

-- Start LCFW --
1.Execute "LME Launcher for 6.60" from XMB.
2. enjoy :)

-- How to enter RecoveryMenu? --
From XMB :Open VshMenu and select "Enter Recovery ->"
From LCFW:Execute Launcher again.
From OFW :Execute Launcher with hold "R".

-- How to mount UmdVideo? --
0. Enable UmdVideo option at RecoveryMenu->config->Use UmdVideo Patch (Go only).
1. copy Iso file at ms(ef)0:/ISO/VIDEO/ .
2. Open VshMenu and select Iso file name.

-- Credit --
some1/Davee/Proxima/Zecoxao: For their kxploit.
liquidzigong	: For his 639kxploit POC.
bbtgp		: For his PrxEncrypter.
Draan		: For his kirk-engine code.
J416		: For his rebootex sample.
N-zaki		: For providing PSPGo from him.
BombingBasta	: For his translated language file in French.
Rapper_skull	: For his translated language file in Italian.
The Z 		: For his translated language file in German.
largeroliker 	: For his translated language file in Spanish.
bassiw		: For his translated language file in Netherlands.
Moz		: For his translated language file in Italian.
Publikacii	: For his translated language file in Bulgarian.
Yoti		: For his translated language file in Russian.
ExzoTikFruiT	: For his translated language file in Russian.
ABCanG &Dadrfy &estuibal &plum &SnyFbSx &teck4 &wn : For their work to collect nid list.
Tipped OuT	: For his EBOOT.PBP ICON0.


--History--
v1.7
-- Fixed a freeze bug when enter sleep with SpeedUpMs option is Enabled.
-- Added a Text color option in Recovery menu.
-- Refactor code.
v1.6
-- Change CPU clock from 199/99 to 200/100.;
-- Update VshMenu. Now you can use translate text.
-- Fixed a ISO size when dump it through USB in XMB.
v1.5
-- Added a 199/99 CPU clock.
-- Fixed a bug in VshMenu when save config.
-- Optimizing the patch.
v1.4
-- Fixed USB Connect in Recovery menu.(05g only).
-- Update VshMenu.
1.3
-- Added Backup/Restore Netconfig option in Recovery menu.
-- Fixed a bug when Use VshMenu while using RemotePlay, Skype, 1seg and PSN-store.
v1.2
-- Update RecoveryMenu.
-- Added a 166/83 CPU clock.
v1.1
-- Update version.txt loading. Now you can load txt from ms0:/seplugins/version.txt.
-- Update NidResolver for FuSa_SD.prx.
v1
-- Fixed a bug in sctrlHENPatchSyscall.
beta3
-- Fixed a bug when use Normal_driver.
-- Fixed a bug when selece Video on XMB.
beta2
-- Fixed a bug when execute converted PS1.
beta
-- First release.


