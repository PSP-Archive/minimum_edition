This plugin is Dark_AleX's LEDA (- Legacy Software Loader).

-- how to use --
1.Copy this plugin at memory stick.
2.Add plugin path at game.txt .


-- Tested Legacy game -- 
Resurssiklunssi v0.3 ( you need not to put sysmem.prx).